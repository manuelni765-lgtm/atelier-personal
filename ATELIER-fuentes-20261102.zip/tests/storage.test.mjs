import assert from "node:assert/strict";
import { test } from "node:test";
import { indexedDB } from "fake-indexeddb";
import JSZip from "jszip";

let downloadedBlob;
globalThis.indexedDB = indexedDB;
globalThis.window = { indexedDB, setTimeout() {} };
globalThis.document = {
  body: { appendChild() {} },
  createElement() { return { href: "", download: "", click() {}, remove() {} }; },
};
globalThis.URL.createObjectURL = (blob) => { downloadedBlob = blob; return "blob:atelier-test"; };
globalThis.URL.revokeObjectURL = () => {};

const { addGarment, getWardrobe, updateGarmentPhoto, removeGarment, addOutfit, exportBackup, importBackup, getAvatarPortrait, saveAvatarPortrait, removeAvatarPortrait } = await import("../src/storage.ts");

test("guarda prendas, conserva favoritos y permite recuperar el armario mediante ZIP", async () => {
  const garment = (id, category) => ({
    id, category, name: `Prenda ${id}`, color: "negro", style: "casual",
    createdAt: Date.now(), photo: new Blob(["contenido-de-foto"], { type: "image/png" }),
  });
  for (const record of [garment("camisa-1", "top"), garment("mocho-1", "shorts"), garment("zapato-1", "shoes")]) {
    await addGarment(record);
  }
  await addOutfit({ id: "look-1", occasion: "casual", garmentIds: ["camisa-1", "mocho-1", "zapato-1"], createdAt: Date.now() });
  const replaced = new Blob(["transparente"], { type: "image/png" });
  await updateGarmentPhoto("camisa-1", replaced);
  const edited = await getWardrobe();
  assert.equal(await edited.garments.find(g => g.id === "camisa-1").photo.text(), "transparente", "puede corregirse la foto sin perder su ID");
  assert.equal(edited.outfits.length, 1, "cambiar el fondo no elimina conjuntos guardados");
  await saveAvatarPortrait(new Blob(["imagen-privada-avatar"], { type: "image/webp" }));
  assert.equal((await getWardrobe()).garments.length, 3);
  assert.equal((await getWardrobe()).outfits.length, 1);

  const filename = await exportBackup("Stiven");
  assert.match(filename, /^ATELIER-respaldo-\d{4}-\d\d-\d\d\.zip$/);
  assert.ok(downloadedBlob.size > 0);
  const exportedZip = await JSZip.loadAsync(downloadedBlob);
  const exportManifest = JSON.parse(await exportedZip.file("armario.json").async("string"));
  assert.equal(exportManifest.portrait, null, "el respaldo nuevo no exporta la foto del avatar retirado");

  await removeAvatarPortrait();
  assert.equal(await getAvatarPortrait(), null);

  await removeGarment("camisa-1");
  const afterRemoval = await getWardrobe();
  assert.equal(afterRemoval.garments.length, 2);
  assert.equal(afterRemoval.outfits.length, 0, "eliminar una prenda retira los looks afectados");

  const restored = await importBackup(new File([downloadedBlob], "respaldo.zip", { type: "application/zip" }));
  assert.equal(restored.count, 3);
  assert.equal(restored.displayName, "Stiven");
  const afterRestore = await getWardrobe();
  assert.equal(afterRestore.garments.length, 3);
  assert.equal(afterRestore.outfits.length, 1);
  assert.equal(afterRestore.garments.find((g) => g.id === "camisa-1")?.photo.type, "image/png");
  assert.equal(await getAvatarPortrait(), null, "el respaldo nuevo no restaura un avatar retirado");

  await assert.rejects(importBackup(new File(["archivo inválido"], "falso.zip")), /ZIP válido/);
  assert.equal((await getWardrobe()).garments.length, 3, "los respaldos inválidos no borran el armario");
});

test("las copias v1 del armario siguen siendo compatibles", async () => {
  const backup = await JSZip.loadAsync(downloadedBlob);
  const manifest = JSON.parse(await backup.file("armario.json").async("string"));
  manifest.version = 1;
  delete manifest.portrait;
  backup.file("armario.json", JSON.stringify(manifest));
  backup.remove("avatar");
  const legacy = await backup.generateAsync({ type: "blob" });

  const before = await getAvatarPortrait();
  const result = await importBackup(new File([legacy], "copia-antigua.zip", { type: "application/zip" }));
  assert.equal(result.count, 3);
  assert.equal((await getAvatarPortrait())?.size, before?.size, "restaurar una copia v1 no modifica datos antiguos ajenos al armario");
});

test("la actualización de IndexedDB v1 a v2 conserva las prendas existentes", async () => {
  await new Promise((resolve, reject) => {
    const req = indexedDB.deleteDatabase("atelier-personal-v1");
    req.onsuccess = resolve;
    req.onerror = () => reject(req.error);
  });
  await new Promise((resolve, reject) => {
    const req = indexedDB.open("atelier-personal-v1", 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore("garments", { keyPath: "id" });
      req.result.createObjectStore("outfits", { keyPath: "id" });
    };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction("garments", "readwrite");
      tx.objectStore("garments").add({ id: "antigua-1", category: "top", name: "Camisa original", color: "blanco", style: "casual", createdAt: 1, photo: new Blob(["foto original"], { type: "image/png" }) });
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => reject(tx.error);
    };
    req.onerror = () => reject(req.error);
  });
  assert.equal((await getWardrobe()).garments[0].name, "Camisa original");
  await saveAvatarPortrait(new Blob(["avatar"], { type: "image/png" }));
  assert.equal((await getWardrobe()).garments[0].id, "antigua-1");
});
