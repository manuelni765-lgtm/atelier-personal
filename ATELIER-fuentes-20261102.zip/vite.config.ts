import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  // Las rutas relativas sirven tanto en / como en /nombre-del-repositorio/ de GitHub Pages.
  base: "./",
  server: { allowedHosts: ["terminal.local"] },
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      injectRegister: "auto",
      includeAssets: ["favicon.svg", "apple-touch-icon.png"],
      manifest: {
        id: "./",
        name: "ATELIER · Mi armario personal",
        short_name: "ATELIER",
        description: "Organiza tus prendas y crea combinaciones sin pagar ni iniciar sesión.",
        lang: "es",
        theme_color: "#2d382e",
        background_color: "#faf9f6",
        display: "standalone",
        start_url: "./",
        scope: "./",
        icons: [
          { src: "icon-192.png", sizes: "192x192", type: "image/png", purpose: "any maskable" },
          { src: "icon-512.png", sizes: "512x512", type: "image/png", purpose: "any maskable" },
        ],
      },
      workbox: {
        navigateFallback: "index.html",
        // El probador de fotos funciona sin WebGL y sin descargas de modelos 3D.
        maximumFileSizeToCacheInBytes: 3 * 1024 * 1024,
        globPatterns: ["**/*.{js,css,html,svg,png,webmanifest}"],
      },
    }),
  ],
});
