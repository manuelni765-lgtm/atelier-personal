# ATELIER — Tu armario personal

ATELIER es una PWA (app web instalable) **completamente gratuita**, sin ChatGPT, Gemini, Firebase, base de datos externa, API de pago ni tarjeta bancaria.

## Lo que ya puedes hacer

- Añadir fotos de camisas, pantalones, mochos, zapatos y gorras.
- Organizar por categoría, color y estilo; buscar y eliminar prendas.
- Generar outfits con tus prendas; volver a generar y bloquear las piezas que te gusten.
- Guardar looks favoritos.
- Previsualizar camisas, pantalones o mochos y zapatos **unidos en una sola composición**, sin avatar ni fotografías separadas.
- Personalizar el probador con prendas de tu armario y generar nuevas combinaciones.
- Abrir capturas de tiendas en ATELIER Studio, ajustar el recorte de la zona de la prenda y quitar el fondo con un modelo de IA ejecutado en el dispositivo (sin subir fotos a un servidor).
- Corregir imperfecciones con un borrador táctil y volver a editar fotos que ya están guardadas sin perder outfits favoritos.
- Ajustar escala, posición vertical y posición horizontal de cada prenda en el probador.
- Crear un ZIP con las prendas, fotografías y favoritos; restaurarlo en otro dispositivo.
- Usarla instalada y sin internet **después de la primera carga**.

## Para usarla en tu computadora (opcional)

Requisitos: Node.js 22 o superior.

```bash
npm ci
npm run dev
```

Abre el enlace local que muestra la terminal (normalmente `http://localhost:5173`).

Para comprobar la compilación final:

```bash
npm run build
npm run preview
```

## Publicarla gratis en GitHub Pages

**¿Prefieres hacerlo sin terminal?** Si recibiste el ZIP `ATELIER_PWA_LISTO_PARA_PUBLICAR.zip`, usa la guía `PUBLICAR_SIN_TERMINAL.md`. Lo siguiente es para publicar el código editable y recibir actualizaciones automáticas.

1. Crea una cuenta propia en [GitHub](https://github.com/) si todavía no tienes una. **No añadas tarjeta ni actives servicios de pago.**
2. Crea un repositorio **público** llamado por ejemplo `atelier-personal`, sin archivos iniciales. GitHub Pages con una cuenta GitHub Free requiere repositorios públicos.
3. En la carpeta descomprimida ejecuta los siguientes comandos (reemplaza `TU_USUARIO`):

   ```bash
   git init
   git add .
   git commit -m "ATELIER PWA personal"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/atelier-personal.git
   git push -u origin main
   ```

4. En GitHub entra al repositorio → **Settings** → **Pages** → **Build and deployment** → **Source: GitHub Actions**.
5. Abre **Actions** y deja que termine el flujo `Publicar ATELIER en GitHub Pages`. Puedes volver a ejecutarlo con `Run workflow` si fuese necesario.
6. Tu web quedará en `https://TU_USUARIO.github.io/atelier-personal/`.

Este proyecto incluye `.github/workflows/deploy.yml`: construye y publica ATELIER automáticamente con cada cambio a `main`. No necesita secretos ni variables de entorno.

Si en GitHub Pages está seleccionada la fuente **Deploy from a branch**, cámbiala a **GitHub Actions**.

## Instalar en el celular

- **Android / Chrome:** abre el enlace de GitHub Pages → menú ⋮ → **Instalar aplicación** o **Añadir a pantalla de inicio**.
- **iPhone / Safari:** abre el enlace → **Compartir** → **Añadir a pantalla de inicio**.

La primera visita necesita internet. Una vez instalada y cargada correctamente, la interfaz y los datos guardados se pueden usar sin conexión. **ATELIER Studio** necesita internet la primera vez que se utiliza la opción de IA para descargar un modelo grande; la disponibilidad posterior sin conexión depende de la caché que conserve el navegador.

## Privacidad y copias de seguridad

Todos los datos quedan guardados **localmente en el navegador** usando IndexedDB. El código de GitHub será público, pero **tu ropa y tus fotos nunca se incluyen en el repositorio ni se suben a GitHub**. No hay sincronización automática entre celulares.

El probador visual utiliza solamente las fotos de tus prendas. Las nuevas copias ZIP no incluyen la imagen del avatar que ofrecían versiones anteriores. Si previamente guardaste una foto de avatar, el navegador puede conservarla como dato antiguo hasta que decidas borrar sus datos; no se muestra ni se sube a internet.

**MUY IMPORTANTE:** Si borras los datos del navegador, cambias de dispositivo, utilizas modo incógnito o el navegador elimina almacenamiento local, podrías perder la colección. En la sección **Mis copias** presiona **Descargar copia ZIP** y guarda ese archivo en un lugar seguro (por ejemplo, tu Google Drive personal). Para cambiar de teléfono, abre ATELIER en el nuevo y usa **Restaurar mi armario**. Esta última acción reemplaza el armario local actual.

La aplicación intenta solicitar almacenamiento persistente cuando el navegador lo permite, pero esto **no sustituye una copia ZIP**.

## Estructura principal

```text
src/wardrobe-app.tsx    Interfaz y generador de outfits
src/outfit-collage.tsx  Vista unida de prendas y ajustes de tamaño/posición
src/garment-editor.tsx  Recorte de capturas, IA de fondo y borrador manual
src/storage.ts         IndexedDB y respaldo ZIP
src/globals.css        Estilo crema / verde oliva
vite.config.ts         PWA instalable y configuración para GitHub Pages
public/                Íconos públicos
.github/workflows/     Publicación automática gratuita
```

## Limitaciones de esta versión

- No se sincroniza automáticamente entre dispositivos: transfiere el ZIP cuando lo necesites.
- El navegador puede limitar cuánto espacio ocupan las fotos; se comprimen a WebP cuando es compatible.
- El generador de outfits utiliza reglas de color y estilo **locales**, no IA externa.
- El probador une visualmente las fotos, pero no simula tallas ni cómo cae físicamente la ropa.
- El recorte previo de capturas es estimado; antes de quitar el fondo, ajusta los bordes si hay etiquetas o botones. La IA funciona mejor cuando la imagen incluye solamente una prenda. Fotos de pantalones puestos en una persona pueden conservar partes del cuerpo: revisa el resultado antes de guardar.
- La eliminación de fondo con IA necesita descargar un modelo al dispositivo la primera vez y puede tardar o fallar en celulares con poca memoria. Existe una opción rápida y un borrador sin IA.
- No hay pantalla de contraseña: quien tenga acceso al dispositivo y al navegador puede ver su armario local.

## Tecnologías

React, TypeScript, Vite, vite-plugin-pwa, IndexedDB, JSZip y lucide-react. Son herramientas gratuitas que se ejecutan en el navegador. GitHub Pages aloja únicamente los archivos estáticos.

**Licencia de la herramienta de IA:** ATELIER Studio usa `@imgly/background-removal` (IMG.LY), bajo GNU Affero General Public License v3. Se mantiene un archivo con el código fuente correspondiente y el texto de licencia para esta versión pública. La biblioteca no necesita API ni tarjeta; puede descargar modelos y archivos de ejecución desde el proveedor en la primera sesión, pero no envía las fotos para procesarlas.
