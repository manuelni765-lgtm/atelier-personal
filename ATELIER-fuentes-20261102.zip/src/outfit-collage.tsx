import { useEffect, useState } from "react";
import type { CSSProperties } from "react";

export type OutfitPiece = { id: string; name: string; imageUrl: string; category?: string };
export type OutfitPieces = {
  top?: OutfitPiece;
  bottom?: OutfitPiece;
  shoes?: OutfitPiece;
  cap?: OutfitPiece;
};
export type OutfitAdjustment = { scale: number; x: number; y: number };
export type OutfitAdjustments = Partial<Record<keyof OutfitPieces, OutfitAdjustment>>;

// A small, device-only cutout for clothes photographed on a solid background.
// Busy scenes are kept intact instead of accidentally erasing the garment.
async function prepareGarment(url: string): Promise<string> {
  const image = new Image();
  image.src = url;
  await image.decode();
  const limit = 700;
  const scale = Math.min(1, limit / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * scale));
  const height = Math.max(1, Math.round(image.naturalHeight * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) return url;
  context.drawImage(image, 0, 0, width, height);
  const pixels = context.getImageData(0, 0, width, height);
  const data = pixels.data;
  const count = width * height;
  const corners = [0, width - 1, (height - 1) * width, count - 1];
  const bg = [0, 1, 2].map((channel) => corners.reduce((sum, index) => sum + data[index * 4 + channel], 0) / 4);
  const diff = (index: number) => {
    const offset = index * 4;
    return Math.abs(data[offset] - bg[0]) + Math.abs(data[offset + 1] - bg[1]) + Math.abs(data[offset + 2] - bg[2]);
  };

  let transparent = 0;
  let similar = 0;
  let perimeter = 0;
  for (let x = 0; x < width; x += Math.max(1, Math.floor(width / 45))) {
    for (const y of [0, height - 1]) {
      const index = y * width + x;
      perimeter++;
      if (data[index * 4 + 3] < 220) transparent++;
      if (diff(index) < 60) similar++;
    }
  }
  for (let y = 0; y < height; y += Math.max(1, Math.floor(height / 45))) {
    for (const x of [0, width - 1]) {
      const index = y * width + x;
      perimeter++;
      if (data[index * 4 + 3] < 220) transparent++;
      if (diff(index) < 60) similar++;
    }
  }

  if (transparent < perimeter * 0.12 && similar > perimeter * 0.82) {
    const seen = new Uint8Array(count);
    const stack: number[] = [];
    for (let x = 0; x < width; x++) { stack.push(x, (height - 1) * width + x); }
    for (let y = 0; y < height; y++) { stack.push(y * width, y * width + width - 1); }
    while (stack.length) {
      const index = stack.pop()!;
      if (seen[index]) continue;
      seen[index] = 1;
      if (diff(index) > 68) continue;
      data[index * 4 + 3] = 0;
      const x = index % width;
      if (x > 0) stack.push(index - 1);
      if (x < width - 1) stack.push(index + 1);
      if (index >= width) stack.push(index - width);
      if (index < count - width) stack.push(index + width);
    }
  }

  let minX = width, minY = height, maxX = -1, maxY = -1;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const index = (y * width + x) * 4;
    if (data[index + 3] < 60) continue;
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  }
  if (maxX < 0) return url;
  const margin = 3;
  minX = Math.max(0, minX - margin);
  minY = Math.max(0, minY - margin);
  maxX = Math.min(width - 1, maxX + margin);
  maxY = Math.min(height - 1, maxY + margin);
  context.putImageData(pixels, 0, 0);
  const trimmed = document.createElement("canvas");
  trimmed.width = maxX - minX + 1;
  trimmed.height = maxY - minY + 1;
  trimmed.getContext("2d")?.drawImage(canvas, minX, minY, trimmed.width, trimmed.height, 0, 0, trimmed.width, trimmed.height);
  return trimmed.toDataURL("image/png");
}

function Piece({ item, role, adjust }: { item?: OutfitPiece; role: keyof OutfitPieces; adjust?: OutfitAdjustment }) {
  const [imageUrl, setImageUrl] = useState(item?.imageUrl || "");
  useEffect(() => {
    let live = true;
    setImageUrl(item?.imageUrl || "");
    if (item) void prepareGarment(item.imageUrl)
      .then((url) => { if (live) setImageUrl(url); })
      .catch(() => { /* Keep original photograph when the browser cannot process it */ });
    return () => { live = false; };
  }, [item?.id, item?.imageUrl]);
  if (!item) return null;
  const vars = {
    "--outfit-scale": adjust?.scale ?? 1,
    "--outfit-x": `${adjust?.x ?? 0}%`,
    "--outfit-y": `${adjust?.y ?? 0}%`,
  } as CSSProperties;
  return <img className={`outfit-layer outfit-layer-${role}`} src={imageUrl} alt={item.name} draggable={false} style={vars}/>;
}

export function OutfitCollage({ pieces, compact = false, adjustments }: { pieces: OutfitPieces; compact?: boolean; adjustments?: OutfitAdjustments }) {
  const hasClothes = Boolean(pieces.top || pieces.bottom || pieces.shoes);
  return <div className={`outfit-composition ${compact ? "outfit-composition-compact" : ""} ${pieces.bottom?.category === "shorts" ? "outfit-composition-shorts" : ""}`} role="img" aria-label={hasClothes ? `Conjunto unido: ${[pieces.cap?.name, pieces.top?.name, pieces.bottom?.name, pieces.shoes?.name].filter(Boolean).join(", ")}` : "Vista previa de tu conjunto"}>
    <div className="outfit-composition-inner" aria-hidden="true">
      <Piece item={pieces.shoes} role="shoes" adjust={adjustments?.shoes}/>
      <Piece item={pieces.bottom} role="bottom" adjust={adjustments?.bottom}/>
      <Piece item={pieces.top} role="top" adjust={adjustments?.top}/>
      <Piece item={pieces.cap} role="cap" adjust={adjustments?.cap}/>
    </div>
    {!hasClothes && <div className="outfit-placeholder"><span>ATELIER / LOOK 001</span><strong>Tu próximo<br/><em>outfit.</em></strong><p>Camisa + pantalón + zapatos, unidos en una sola vista.</p></div>}
  </div>;
}
