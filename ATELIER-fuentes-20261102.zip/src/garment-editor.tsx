import { useEffect, useRef, useState } from "react";
import { Check, Crop, Eraser, RefreshCw, RotateCcw, Sparkles, X } from "lucide-react";

type Rect = { x: number; y: number; w: number; h: number };
type Props = { source: File; onCancel: () => void; onDone: (photo: File) => void };

function guessCrop(width: number, height: number): Rect {
  // Tall mobile shop screenshots generally contain headers and price panels.
  // The visitor can move every edge before any pixels are discarded.
  if (height / width > 1.75 && width < 1500) return { x: .045, y: .125, w: .91, h: .59 };
  return { x: 0, y: 0, w: 1, h: 1 };
}

async function loadBitmap(file: Blob): Promise<ImageBitmap> {
  try { return await createImageBitmap(file); }
  catch { throw new Error("No pudimos abrir esta imagen. Convierte la foto a JPG o PNG e inténtalo."); }
}

async function cropSource(source: File, rect: Rect): Promise<Blob> {
  const bitmap = await loadBitmap(source);
  try {
    const sx = Math.round(rect.x * bitmap.width);
    const sy = Math.round(rect.y * bitmap.height);
    const sw = Math.min(bitmap.width - sx, Math.max(1, Math.round(rect.w * bitmap.width)));
    const sh = Math.min(bitmap.height - sy, Math.max(1, Math.round(rect.h * bitmap.height)));
    const factor = Math.min(1, 1300 / Math.max(sw, sh));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(sw * factor));
    canvas.height = Math.max(1, Math.round(sh * factor));
    canvas.getContext("2d")?.drawImage(bitmap, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("No se pudo recortar la fotografía.");
    return blob;
  } finally { bitmap.close(); }
}

// A local fallback for simple photographic backgrounds when the AI model cannot load.
async function removeFlatBackground(blob: Blob): Promise<Blob> {
  const bitmap = await loadBitmap(blob);
  const canvas = document.createElement("canvas");
  canvas.width = bitmap.width; canvas.height = bitmap.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) { bitmap.close(); return blob; }
  ctx.drawImage(bitmap, 0, 0);
  bitmap.close();
  const frame = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = frame.data, width = canvas.width, height = canvas.height;
  const points = [0, width - 1, width * (height - 1), width * height - 1];
  const bg = [0, 1, 2].map(c => points.reduce((sum, p) => sum + data[p * 4 + c], 0) / 4);
  const difference = (p: number) => Math.abs(data[p * 4] - bg[0]) + Math.abs(data[p * 4 + 1] - bg[1]) + Math.abs(data[p * 4 + 2] - bg[2]);
  const edges = [] as number[];
  for (let x = 0; x < width; x++) edges.push(x, x + (height - 1) * width);
  for (let y = 0; y < height; y++) edges.push(y * width, y * width + width - 1);
  const match = edges.filter(p => difference(p) < 70).length / edges.length;
  if (match < .73) return blob;
  const seen = new Uint8Array(width * height);
  while (edges.length) {
    const p = edges.pop()!;
    if (seen[p]) continue;
    seen[p] = 1;
    if (difference(p) > 78) continue;
    data[p * 4 + 3] = 0;
    const x = p % width;
    if (x) edges.push(p - 1);
    if (x < width - 1) edges.push(p + 1);
    if (p >= width) edges.push(p - width);
    if (p < width * (height - 1)) edges.push(p + width);
  }
  ctx.putImageData(frame, 0, 0);
  return await new Promise<Blob>(resolve => canvas.toBlob(b => resolve(b || blob), "image/png"));
}

async function trimAlpha(blob: Blob): Promise<Blob> {
  const bitmap = await loadBitmap(blob);
  const canvas = document.createElement("canvas");
  canvas.width = bitmap.width; canvas.height = bitmap.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) { bitmap.close(); return blob; }
  ctx.drawImage(bitmap, 0, 0); bitmap.close();
  const px = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  let left = canvas.width, right = -1, top = canvas.height, bottom = -1;
  for (let y = 0; y < canvas.height; y++) for (let x = 0; x < canvas.width; x++) {
    if (px[(y * canvas.width + x) * 4 + 3] < 34) continue;
    left = Math.min(left, x); right = Math.max(right, x); top = Math.min(top, y); bottom = Math.max(bottom, y);
  }
  if (right < left) return blob;
  // Don't zoom into artifacts: retain a small transparent margin around the actual garment.
  left = Math.max(0, left - 9); top = Math.max(0, top - 9);
  right = Math.min(canvas.width - 1, right + 9); bottom = Math.min(canvas.height - 1, bottom + 9);
  const trimmed = document.createElement("canvas");
  trimmed.width = right - left + 1; trimmed.height = bottom - top + 1;
  trimmed.getContext("2d")?.drawImage(canvas, left, top, trimmed.width, trimmed.height, 0, 0, trimmed.width, trimmed.height);
  return await new Promise<Blob>(resolve => trimmed.toBlob(b => resolve(b || blob), "image/png"));
}

export function GarmentEditor({ source, onCancel, onDone }: Props) {
  const [sourceUrl, setSourceUrl] = useState("");
  const [crop, setCrop] = useState<Rect>({ x: 0, y: 0, w: 1, h: 1 });
  const [processed, setProcessed] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [warning, setWarning] = useState("");
  const [brush, setBrush] = useState(24);
  const [erasing, setErasing] = useState(false);
  const [edited, setEdited] = useState(false);
  const [originalBlob, setOriginalBlob] = useState<Blob | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dragRef = useRef(false);

  useEffect(() => {
    if (!processed || !originalBlob) return;
    let active = true;
    void loadBitmap(originalBlob).then(bitmap => {
      if (active && canvasRef.current) {
        const canvas = canvasRef.current;
        canvas.width = bitmap.width; canvas.height = bitmap.height;
        canvas.getContext("2d")?.drawImage(bitmap, 0, 0);
      }
      bitmap.close();
    }).catch(e => { if (active) setError(String(e)); });
    return () => { active = false; };
  }, [processed, originalBlob]);

  useEffect(() => {
    const url = URL.createObjectURL(source);
    setSourceUrl(url);
    let active = true;
    void loadBitmap(source).then(bm => {
      if (active) setCrop(guessCrop(bm.width, bm.height));
      bm.close();
    }).catch(e => { if (active) setError(String(e)); });
    return () => { active = false; URL.revokeObjectURL(url); };
  }, [source]);

  function setEdge(edge: "x" | "y" | "right" | "bottom", value: number) {
    setCrop(old => {
      const v = value / 100;
      if (edge === "x") return { ...old, x: Math.min(v, old.x + old.w - .12), w: old.x + old.w - Math.min(v, old.x + old.w - .12) };
      if (edge === "y") return { ...old, y: Math.min(v, old.y + old.h - .12), h: old.y + old.h - Math.min(v, old.y + old.h - .12) };
      if (edge === "right") return { ...old, w: Math.max(.12, v - old.x) };
      return { ...old, h: Math.max(.12, v - old.y) };
    });
  }

  async function paintResult(blob: Blob) {
    const trimmed = await trimAlpha(blob);
    setOriginalBlob(trimmed);
    setEdited(false);
    setProcessed(true);
  }

  async function process(useAI: boolean) {
    setError(""); setWarning(""); setStatus("Recortando la zona de la prenda…");
    try {
      const cut = await cropSource(source, crop);
      if (useAI) {
        try {
          setStatus("Quitando el fondo con IA en tu dispositivo. La primera vez se descarga el modelo y puede tardar…");
          const { removeBackground } = await import("@imgly/background-removal");
          const result = await removeBackground(cut, {
            // The quantized model uses less RAM on phones, while staying fully local.
            model: "isnet_quint8",
            proxyToWorker: true,
            progress: (key, current, total) => {
              if (total > 0) setStatus(`Descargando IA local: ${Math.min(100, Math.round(current / total * 100))}% · ${key.split("/").pop()}`);
            },
          });
          await paintResult(result);
        } catch (err) {
          await paintResult(await removeFlatBackground(cut));
          setWarning("La IA no pudo ejecutarse aquí. Aplicamos el recorte básico; utiliza el borrador para limpiar lo que sobre. Si quieres reintentar, comprueba tu conexión.");
          console.warn("ATELIER background removal fallback:", err);
        }
      } else {
        await paintResult(await removeFlatBackground(cut));
        setWarning("Recorte rápido. Puedes borrar los restos del fondo manualmente o volver para usar IA.");
      }
    } catch (err) { setError(err instanceof Error ? err.message : "No se pudo editar la imagen."); }
    finally { setStatus(""); }
  }

  function eraseAt(event: React.PointerEvent<HTMLCanvasElement>) {
    if (!dragRef.current || !erasing) return;
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    const bounds = canvas.getBoundingClientRect();
    const x = (event.clientX - bounds.left) * canvas.width / bounds.width;
    const y = (event.clientY - bounds.top) * canvas.height / bounds.height;
    const radius = brush * canvas.width / 400;
    context.save();
    context.globalCompositeOperation = "destination-out";
    context.beginPath(); context.arc(x, y, radius, 0, 2 * Math.PI); context.fill();
    context.restore();
    setEdited(true);
  }

  async function restoreResult() { if (originalBlob) await paintResult(originalBlob); }

  async function accept() {
    if (!canvasRef.current || status) return;
    setStatus("Guardando imagen transparente…");
    try {
      const result = await new Promise<Blob | null>(resolve => canvasRef.current?.toBlob(resolve, "image/png"));
      if (!result) throw new Error("No se pudo crear el archivo.");
      onDone(new File([result], "atelier-prenda.png", { type: "image/png" }));
    } catch (err) { setError(err instanceof Error ? err.message : "No se pudo guardar la imagen."); }
    finally { setStatus(""); }
  }

  return <div className="modal-backdrop garment-editor-overlay"><div className="garment-editor" role="dialog" aria-modal="true" aria-labelledby="editor-title">
    <div className="modal-heading"><div><span className="page-kicker">ATELIER / STUDIO</span><h2 id="editor-title">Preparar prenda<span className="serif-dot">.</span></h2></div><button aria-label="Cerrar editor" disabled={!!status} onClick={onCancel}><X size={22}/></button></div>
    <p className="editor-intro">Recortamos capturas de tiendas y quitamos el fondo para que tu ropa se una bien en el probador.</p>
    {!processed ? <>
      <div className="crop-visual" aria-label="Vista de recorte"><img src={sourceUrl} alt="Fotografía original" draggable={false}/><div className="crop-boundary" style={{ left: `${crop.x * 100}%`, top: `${crop.y * 100}%`, width: `${crop.w * 100}%`, height: `${crop.h * 100}%` }}><span>PRENDA</span></div></div>
      <p className="editor-tip">Ajusta el rectángulo para incluir solo la prenda, sin precios, menús ni botones.</p>
      <div className="crop-controls">
        {([ ["x", "Izquierda", crop.x], ["right", "Derecha", crop.x + crop.w], ["y", "Arriba", crop.y], ["bottom", "Abajo", crop.y + crop.h] ] as const).map(([key, label, current]) => <label key={key}><span>{label}</span><input type="range" min={key === "right" || key === "bottom" ? 12 : 0} max="100" value={Math.round(current * 100)} onChange={e => setEdge(key, Number(e.target.value))}/></label>)}
      </div>
      <button type="button" className="editor-reset" onClick={() => setCrop({ x: 0, y: 0, w: 1, h: 1 })}><RotateCcw size={14}/> Usar fotografía completa</button>
      <button type="button" className="btn btn-dark editor-primary" disabled={!!status} onClick={() => void process(true)}><Sparkles size={17}/> Recortar y quitar fondo con IA</button>
      <button type="button" className="btn btn-outline editor-secondary" disabled={!!status} onClick={() => void process(false)}><Crop size={16}/> Recorte rápido (sin IA)</button>
    </> : <>
      <div className="editor-result"><span className="editor-badge"><Check size={14}/> VISTA PREVIA</span><canvas ref={canvasRef} className={erasing ? "erasing" : ""} aria-label="Prenda sin fondo" onPointerDown={e => { dragRef.current = true; e.currentTarget.setPointerCapture(e.pointerId); eraseAt(e); }} onPointerMove={eraseAt} onPointerUp={() => { dragRef.current = false; }} onPointerCancel={() => { dragRef.current = false; }}/></div>
      <p className="editor-tip">¿Quedó algo del fondo? Activa el borrador y desliza el dedo sobre lo que sobra.</p>
      <div className="editor-brush"><button className={`btn ${erasing ? "btn-dark" : "btn-outline"}`} onClick={() => setErasing(v => !v)}><Eraser size={15}/> {erasing ? "Borrador activo" : "Activar borrador"}</button><label>Grosor <input type="range" min="6" max="65" value={brush} onChange={e => setBrush(Number(e.target.value))}/></label><button className="editor-reset" disabled={!edited} onClick={() => void restoreResult()}><RotateCcw size={15}/> Deshacer borrado</button></div>
      <button type="button" className="btn btn-dark editor-primary" disabled={!!status} onClick={() => void accept()}><Check size={17}/> Usar esta prenda</button>
      <button type="button" className="btn btn-outline editor-secondary" disabled={!!status} onClick={() => { setProcessed(false); setOriginalBlob(null); setWarning(""); }}><Crop size={16}/> Volver al recorte</button>
    </>}
    {status && <p className="editor-processing" role="status"><RefreshCw className="spin" size={16}/>{status}</p>}
    {warning && <p className="editor-warning" role="status">{warning}</p>}
    {error && <p className="editor-error" role="alert">{error}</p>}
    <small className="editor-privacy">Gratis · El procesamiento ocurre en este dispositivo. La IA necesita descargar su modelo la primera vez.</small>
  </div></div>;
}
