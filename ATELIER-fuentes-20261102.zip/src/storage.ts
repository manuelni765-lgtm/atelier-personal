import JSZip from "jszip";

export type Category = "top" | "pants" | "shorts" | "shoes" | "cap";
export type Color = "negro" | "blanco" | "gris" | "beige" | "azul" | "azul-marino" | "café" | "verde" | "rojo" | "otro";
export type Style = "casual" | "urbano" | "elegante" | "deportivo";

export interface StoredGarment {
  id: string;
  name: string;
  category: Category;
  color: Color;
  style: Style;
  photo: Blob;
  createdAt: number;
}

export interface StoredOutfit {
  id: string;
  occasion: Style;
  garmentIds: string[];
  createdAt: number;
}

const DB_NAME = "atelier-personal-v1";
const DB_VERSION = 2;
const GARMENTS = "garments";
const OUTFITS = "outfits";
const AVATAR = "avatar";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error("Este navegador no permite guardar el armario localmente."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(GARMENTS)) db.createObjectStore(GARMENTS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(OUTFITS)) db.createObjectStore(OUTFITS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(AVATAR)) db.createObjectStore(AVATAR, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("No se pudo abrir el armario."));
    req.onblocked = () => reject(new Error("Cierra otras pestañas de ATELIER y vuelve a intentarlo."));
  });
}

function request<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("Error al leer los datos."));
  });
}

function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error("No se pudieron guardar los cambios."));
    tx.onabort = () => reject(tx.error || new Error("La operación fue cancelada."));
  });
}

export async function getWardrobe(): Promise<{ garments: StoredGarment[]; outfits: StoredOutfit[] }> {
  const db = await openDatabase();
  try {
    const tx = db.transaction([GARMENTS, OUTFITS], "readonly");
    const garmentsRequest = request<StoredGarment[]>(tx.objectStore(GARMENTS).getAll());
    const outfitsRequest = request<StoredOutfit[]>(tx.objectStore(OUTFITS).getAll());
    const [garments, outfits] = await Promise.all([garmentsRequest, outfitsRequest]);
    return {
      garments: garments.sort((a, b) => b.createdAt - a.createdAt),
      outfits: outfits.sort((a, b) => b.createdAt - a.createdAt),
    };
  } finally {
    db.close();
  }
}

export async function addGarment(garment: StoredGarment): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(GARMENTS, "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(GARMENTS).add(garment);
    await done;
  } finally {
    db.close();
  }
}

export async function updateGarmentPhoto(id: string, photo: Blob): Promise<void> {
  if (!imageTypes.has(photo.type) || !photo.size || photo.size > 15 * 1024 * 1024) {
    throw new Error("La fotografía editada debe ser JPG, PNG o WebP y pesar menos de 15 MB.");
  }
  const db = await openDatabase();
  try {
    const tx = db.transaction(GARMENTS, "readwrite");
    const done = transactionDone(tx);
    const store = tx.objectStore(GARMENTS);
    const old = store.get(id);
    old.onsuccess = () => {
      const garment = old.result as StoredGarment | undefined;
      if (garment) store.put({ ...garment, photo });
      else tx.abort();
    };
    await done;
  } finally { db.close(); }
}

export async function removeGarment(id: string): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction([GARMENTS, OUTFITS], "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(GARMENTS).delete(id);
    const outfits = tx.objectStore(OUTFITS);
    const existing = outfits.getAll();
    existing.onsuccess = () => {
      for (const outfit of existing.result as StoredOutfit[]) {
        if (outfit.garmentIds.includes(id)) outfits.delete(outfit.id);
      }
    };
    await done;
  } finally {
    db.close();
  }
}

export async function addOutfit(outfit: StoredOutfit): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(OUTFITS, "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(OUTFITS).add(outfit);
    await done;
  } finally {
    db.close();
  }
}

export async function removeOutfit(id: string): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(OUTFITS, "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(OUTFITS).delete(id);
    await done;
  } finally {
    db.close();
  }
}

// La foto de referencia es privada: se guarda en IndexedDB, nunca en GitHub.
export async function getAvatarPortrait(): Promise<Blob | null> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(AVATAR, "readonly");
    const result = await request<{ id: string; photo: Blob } | undefined>(tx.objectStore(AVATAR).get("portrait"));
    return result?.photo || null;
  } finally { db.close(); }
}

export async function saveAvatarPortrait(photo: Blob): Promise<void> {
  if (!imageTypes.has(photo.type) || !photo.size || photo.size > 10 * 1024 * 1024) {
    throw new Error("Usa una foto JPG, PNG o WebP de máximo 10 MB.");
  }
  const db = await openDatabase();
  try {
    const tx = db.transaction(AVATAR, "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(AVATAR).put({ id: "portrait", photo });
    await done;
  } finally { db.close(); }
}

export async function removeAvatarPortrait(): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(AVATAR, "readwrite");
    const done = transactionDone(tx);
    tx.objectStore(AVATAR).delete("portrait");
    await done;
  } finally { db.close(); }
}

export async function requestPersistentStorage(): Promise<boolean> {
  if (!navigator.storage?.persist) return false;
  try { return await navigator.storage.persist(); } catch { return false; }
}

interface BackupManifest {
  app: "ATELIER";
  version: 2;
  exportedAt: string;
  displayName: string;
  garments: Array<Omit<StoredGarment, "photo"> & { imageFile: string; imageType: string }>;
  outfits: StoredOutfit[];
  portrait: { imageFile: string; imageType: string } | null;
}

const validCategories = new Set<Category>(["top", "pants", "shorts", "shoes", "cap"]);
const validColors = new Set<Color>(["negro", "blanco", "gris", "beige", "azul", "azul-marino", "café", "verde", "rojo", "otro"]);
const validStyles = new Set<Style>(["casual", "urbano", "elegante", "deportivo"]);
const imageTypes = new Set(["image/webp", "image/jpeg", "image/png"]);
const safeId = /^[a-zA-Z0-9_-]{1,100}$/;

export async function exportBackup(displayName: string): Promise<string> {
  const { garments, outfits } = await getWardrobe();
  const zip = new JSZip();
  const exportedAt = new Date().toISOString();
  const manifest: BackupManifest = { app: "ATELIER", version: 2, exportedAt, displayName, garments: [], outfits, portrait: null };
  for (const { photo, ...item } of garments) {
    const ext = photo.type === "image/png" ? "png" : photo.type === "image/jpeg" ? "jpg" : "webp";
    const imageFile = `fotos/${item.id}.${ext}`;
    zip.file(imageFile, new Uint8Array(await photo.arrayBuffer()));
    manifest.garments.push({ ...item, imageFile, imageType: photo.type });
  }
  // Las nuevas copias ya no incluyen fotografías del antiguo avatar.
  // El importador conserva compatibilidad con ZIPs antiguos que sí la contenían.
  zip.file("armario.json", JSON.stringify(manifest, null, 2));
  const file = await zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 4 } });
  const name = `ATELIER-respaldo-${exportedAt.slice(0, 10)}.zip`;
  const url = URL.createObjectURL(file);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  return name;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export async function importBackup(file: File): Promise<{ count: number; displayName: string }> {
  if (file.size > 350 * 1024 * 1024) throw new Error("La copia supera el máximo de 350 MB.");
  let zip: JSZip;
  try { zip = await JSZip.loadAsync(file); } catch { throw new Error("El archivo no es un ZIP válido."); }
  const manifestFile = zip.file("armario.json");
  if (!manifestFile) throw new Error("El ZIP no contiene un respaldo de ATELIER.");
  const manifestText = await manifestFile.async("string");
  if (manifestText.length > 2_000_000) throw new Error("El respaldo contiene demasiados datos.");
  let raw: unknown;
  try { raw = JSON.parse(manifestText); } catch { throw new Error("El respaldo está dañado."); }
  if (!isObject(raw) || raw.app !== "ATELIER" || (raw.version !== 1 && raw.version !== 2) || !Array.isArray(raw.garments) || !Array.isArray(raw.outfits)) {
    throw new Error("Este archivo no es una copia compatible de ATELIER.");
  }
  if (raw.garments.length > 3000 || raw.outfits.length > 10000) throw new Error("La copia contiene demasiados registros.");
  const garments: StoredGarment[] = [];
  let totalPhotoBytes = 0;
  const ids = new Set<string>();
  for (const value of raw.garments) {
    if (!isObject(value) || typeof value.id !== "string" || !safeId.test(value.id) || ids.has(value.id) ||
        typeof value.name !== "string" || !value.name.trim() || value.name.length > 100 ||
        !validCategories.has(value.category as Category) || !validColors.has(value.color as Color) ||
        !validStyles.has(value.style as Style) || typeof value.createdAt !== "number" || !Number.isFinite(value.createdAt) ||
        typeof value.imageType !== "string" || !imageTypes.has(value.imageType) ||
        typeof value.imageFile !== "string" || !value.imageFile.startsWith(`fotos/${value.id}.`)) {
      throw new Error("El respaldo contiene una prenda inválida.");
    }
    const entry = zip.file(value.imageFile);
    if (!entry) throw new Error(`Falta la foto de ${value.name}.`);
    const photoData = await entry.async("uint8array");
    totalPhotoBytes += photoData.byteLength;
    if (!photoData.byteLength || photoData.byteLength > 15 * 1024 * 1024 || totalPhotoBytes > 350 * 1024 * 1024) {
      throw new Error("Una fotografía es demasiado grande o la copia supera los 350 MB.");
    }
    ids.add(value.id);
    garments.push({
      id: value.id, name: value.name, category: value.category as Category,
      color: value.color as Color, style: value.style as Style,
      createdAt: value.createdAt, photo: new Blob([Uint8Array.from(photoData)], { type: value.imageType }),
    });
  }
  const outfitIds = new Set<string>();
  const outfits: StoredOutfit[] = [];
  for (const value of raw.outfits) {
    if (!isObject(value) || typeof value.id !== "string" || !safeId.test(value.id) || outfitIds.has(value.id) ||
        !validStyles.has(value.occasion as Style) || typeof value.createdAt !== "number" || !Number.isFinite(value.createdAt) ||
        !Array.isArray(value.garmentIds) || value.garmentIds.length < 3 || value.garmentIds.length > 4 ||
        !value.garmentIds.every((id) => typeof id === "string" && ids.has(id))) {
      throw new Error("El respaldo contiene un conjunto inválido.");
    }
    outfitIds.add(value.id);
    outfits.push({ id: value.id, occasion: value.occasion as Style, createdAt: value.createdAt, garmentIds: value.garmentIds });
  }
  // Las copias antiguas no contenían avatar: se mantiene la foto actual al restaurarlas.
  let portrait: Blob | null = null;
  if (raw.version === 2 && raw.portrait !== null) {
    if (!isObject(raw.portrait) || typeof raw.portrait.imageType !== "string" ||
        !imageTypes.has(raw.portrait.imageType) || typeof raw.portrait.imageFile !== "string" ||
        !/^avatar\/referencia\.(webp|png|jpg)$/.test(raw.portrait.imageFile)) {
      throw new Error("La foto del avatar en el respaldo no es válida.");
    }
    const entry = zip.file(raw.portrait.imageFile);
    if (!entry) throw new Error("Falta la foto del avatar en el respaldo.");
    const data = await entry.async("uint8array");
    if (!data.byteLength || data.byteLength > 10 * 1024 * 1024 || totalPhotoBytes + data.byteLength > 350 * 1024 * 1024) {
      throw new Error("La foto del avatar es demasiado grande.");
    }
    portrait = new Blob([Uint8Array.from(data)], { type: raw.portrait.imageType });
  } else if (raw.version === 2 && raw.portrait === undefined) {
    throw new Error("La copia no contiene información válida del avatar.");
  }
  // Una única transacción: si falla cualquier foto o registro, se conserva el armario anterior.
  const db = await openDatabase();
  try {
    const tx = db.transaction(raw.version === 2 ? [GARMENTS, OUTFITS, AVATAR] : [GARMENTS, OUTFITS], "readwrite");
    const done = transactionDone(tx);
    const garmentsStore = tx.objectStore(GARMENTS);
    const outfitsStore = tx.objectStore(OUTFITS);
    garmentsStore.clear();
    outfitsStore.clear();
    for (const garment of garments) garmentsStore.add(garment);
    for (const outfit of outfits) outfitsStore.add(outfit);
    if (raw.version === 2) {
      const avatarStore = tx.objectStore(AVATAR);
      avatarStore.clear();
      if (portrait) avatarStore.add({ id: "portrait", photo: portrait });
    }
    await done;
  } finally { db.close(); }
  return { count: garments.length, displayName: typeof raw.displayName === "string" ? raw.displayName.slice(0, 40) : "" };
}
