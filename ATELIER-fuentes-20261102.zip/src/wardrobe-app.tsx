"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight, ArrowUpRight, Check, CheckCheck,
  ChevronRight, CloudUpload, Crop, Footprints, Grid2X2, Heart, Home,
  Layers3, LockKeyhole, Menu, Plus, RefreshCw, Search, Shirt, SlidersHorizontal,
  Sparkles, Trash2, UnlockKeyhole, WandSparkles, X, ArchiveRestore, Download, Upload, ShieldCheck,
} from "lucide-react";
import { addGarment as storeGarment, addOutfit as storeOutfit, exportBackup, getWardrobe, importBackup, removeGarment as deleteStoredGarment, removeOutfit as deleteStoredOutfit, requestPersistentStorage, updateGarmentPhoto } from "./storage";
import type { Category, Color, Style, StoredGarment } from "./storage";
import { OutfitCollage } from "./outfit-collage";
import type { OutfitAdjustments } from "./outfit-collage";
import { GarmentEditor } from "./garment-editor";

type Section = "inicio" | "armario" | "estudio" | "probador" | "favoritos" | "respaldo";
type Role = "top" | "bottom" | "shoes" | "cap";
type Garment = { id: string; name: string; category: Category; color: Color; style: Style; imageUrl: string; createdAt: number };
type Outfit = { id: string; occasion: Style; garmentIds: string[]; createdAt: number };
type Selection = Partial<Record<Role, Garment>>;

const categories: { id: Category; label: string; plural: string }[] = [
  { id: "top", label: "Camisa / camiseta", plural: "Camisas" },
  { id: "pants", label: "Pantalón", plural: "Pantalones" },
  { id: "shorts", label: "Mocho / short", plural: "Mochos" },
  { id: "shoes", label: "Zapatos / tenis", plural: "Zapatos" },
  { id: "cap", label: "Gorra", plural: "Gorras" },
];
const colors: { id: Color; label: string; hex: string }[] = [
  { id: "negro", label: "Negro", hex: "#252522" },
  { id: "blanco", label: "Blanco", hex: "#f5f5f0" },
  { id: "gris", label: "Gris", hex: "#9a9b98" },
  { id: "beige", label: "Beige / crema", hex: "#d5c5a6" },
  { id: "azul", label: "Azul", hex: "#5e84a7" },
  { id: "azul-marino", label: "Azul marino", hex: "#273747" },
  { id: "café", label: "Café", hex: "#82614b" },
  { id: "verde", label: "Verde", hex: "#677963" },
  { id: "rojo", label: "Rojo / vino", hex: "#9b4b4e" },
  { id: "otro", label: "Otro", hex: "conic-gradient(#ba5d9e,#ecc681,#729d9f,#ba5d9e)" },
];
const occasions: { id: Style; label: string; subtitle: string }[] = [
  { id: "casual", label: "Diario", subtitle: "Relajado y natural" },
  { id: "urbano", label: "Urbano", subtitle: "Streetwear y actitud" },
  { id: "elegante", label: "Elegante", subtitle: "Limpio y sofisticado" },
  { id: "deportivo", label: "Deportivo", subtitle: "Cómodo y activo" },
];
const roles: { id: Role; label: string; number: string }[] = [
  { id: "top", label: "Parte superior", number: "01" },
  { id: "bottom", label: "Parte inferior", number: "02" },
  { id: "shoes", label: "Calzado", number: "03" },
  { id: "cap", label: "Accesorio opcional", number: "04" },
];
const neutral = new Set<Color>(["negro", "blanco", "gris", "beige", "azul-marino", "café"]);
const complementary: Record<string, string[]> = {
  azul: ["beige", "blanco", "café", "gris"],
  verde: ["beige", "blanco", "negro", "café"],
  rojo: ["negro", "beige", "gris", "blanco"],
  "azul-marino": ["beige", "blanco", "gris", "café"],
};
const nav: { id: Section; label: string; icon: typeof Home }[] = [
  { id: "inicio", label: "Inicio", icon: Home },
  { id: "armario", label: "Mi armario", icon: Grid2X2 },
  { id: "estudio", label: "Crear outfit", icon: WandSparkles },
  { id: "probador", label: "Probador visual", icon: Layers3 },
  { id: "favoritos", label: "Mis favoritos", icon: Heart },
  { id: "respaldo", label: "Mis copias", icon: ArchiveRestore },
];

function catName(cat: Category) { return categories.find((c) => c.id === cat)?.plural || cat; }
function colorName(color: Color) { return colors.find((c) => c.id === color)?.label || color; }
function occasionName(style: Style) { return occasions.find((c) => c.id === style)?.label || style; }
function randomOf<T>(list: T[]): T | undefined { return list[Math.floor(Math.random() * list.length)]; }
function pairScore(a: Color, b: Color) {
  if (a === b) return neutral.has(a) ? 2.4 : 0.7;
  if (neutral.has(a) && neutral.has(b)) return 3.4;
  if (neutral.has(a) || neutral.has(b)) return 3;
  if (complementary[a]?.includes(b) || complementary[b]?.includes(a)) return 3.2;
  return -0.8;
}
function lookScore(sel: Selection, style: Style) {
  const vals = Object.values(sel).filter(Boolean) as Garment[];
  let points = vals.reduce((sum, g) => sum + (g.style === style ? 2.8 : g.style === "casual" ? 0.9 : 0), 0);
  const { top, bottom, shoes, cap } = sel;
  if (top && bottom) points += pairScore(top.color, bottom.color) * 2;
  if (bottom && shoes) points += pairScore(bottom.color, shoes.color) * 1.4;
  if (top && shoes) points += pairScore(top.color, shoes.color) * 0.7;
  if (cap && top) points += pairScore(cap.color, top.color) * 0.65;
  if (style === "elegante" && bottom?.category === "pants") points += 2;
  if (style === "deportivo" && bottom?.category === "shorts") points += 1.5;
  return points;
}
function makeLook(items: Garment[], occasion: Style, locks: Partial<Record<Role, string>>, prevKey: string, history: string[]) {
  const pool = (role: Role) => {
    const choices = items.filter((g) => role === "bottom" ? ["pants", "shorts"].includes(g.category) : g.category === role);
    return locks[role] ? choices.filter((g) => g.id === locks[role]) : choices;
  };
  const tops = pool("top"); const bottoms = pool("bottom"); const shoes = pool("shoes"); const caps = pool("cap");
  if (!tops.length || !bottoms.length || !shoes.length) return null;
  const scored: { look: Selection; key: string; points: number }[] = [];
  const count = Math.min(250, Math.max(60, tops.length * bottoms.length * shoes.length * Math.max(1, caps.length)));
  for (let n = 0; n < count; n++) {
    const top = randomOf(tops)!; const bottom = randomOf(bottoms)!; const shoe = randomOf(shoes)!;
    const cap = caps.length && (Boolean(locks.cap) || Math.random() < 0.68) ? randomOf(caps) : undefined;
    const look = { top, bottom, shoes: shoe, cap };
    const key = [top.id, bottom.id, shoe.id, cap?.id || ""].join("|");
    if (key === prevKey || history.includes(key)) continue;
    scored.push({ look, key, points: lookScore(look, occasion) + Math.random() * 3 });
  }
  if (!scored.length) return null;
  scored.sort((a, b) => b.points - a.points);
  return randomOf(scored.slice(0, Math.min(7, scored.length)))!;
}
function GarmentSymbol({ category, size = 36 }: { category: Category | "bottom"; size?: number }) {
  if (category === "shoes") return <Footprints size={size} strokeWidth={1.2} />;
  if (category === "cap") return <span className="cap-glyph" style={{ fontSize: size * 0.83 }}>◠</span>;
  if (category === "bottom" || category === "pants" || category === "shorts") return <Layers3 size={size} strokeWidth={1.2} />;
  return <Shirt size={size} strokeWidth={1.2} />;
}
function GarmentImage({ item, category, className = "" }: { item?: Garment; category?: Category | "bottom"; className?: string }) {
  return <div className={`garment-photo ${className}`}>
    {item ? <img src={item.imageUrl} alt={item.name} loading="lazy" /> : <span className="garment-placeholder"><GarmentSymbol category={category || "top"} size={55} /></span>}
  </div>;
}
async function optimizePhoto(file: File): Promise<File> {
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 1500 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", 0.86));
    if (!blob || blob.type !== "image/webp") throw new Error("No se pudo convertir");
    return new File([blob], "prenda.webp", { type: "image/webp" });
  } catch {
    return file;
  }
}

export default function WardrobeApp({ firstName }: { firstName: string }) {
  const [displayName, setDisplayName] = useState(() => {
    try { return localStorage.getItem("atelier-display-name") || firstName; } catch { return firstName; }
  });
  const [section, setSection] = useState<Section>("inicio");
  const [items, setItems] = useState<Garment[]>([]);
  const [favorites, setFavorites] = useState<Outfit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<Category | "all">("all");
  const [search, setSearch] = useState("");
  const [occasion, setOccasion] = useState<Style>("casual");
  const [fittingIds, setFittingIds] = useState<Partial<Record<Role, string>>>({});
  const [current, setCurrent] = useState<Selection | null>(null);
  const [locks, setLocks] = useState<Partial<Record<Role, string>>>({});
  const [addOpen, setAddOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [editorSource, setEditorSource] = useState<File | null>(null);
  const [editingExistingId, setEditingExistingId] = useState<string | null>(null);
  const [fittingAdjustments, setFittingAdjustments] = useState<OutfitAdjustments>({});
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("top");
  const [color, setColor] = useState<Color>("negro");
  const [style, setStyle] = useState<Style>("casual");
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState("");
  const [deleteItem, setDeleteItem] = useState<Garment | null>(null);
  const [dateLabel, setDateLabel] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [lastBackup, setLastBackup] = useState(() => {
    try { return localStorage.getItem("atelier-last-backup") || ""; } catch { return ""; }
  });
  const backupInputRef = useRef<HTMLInputElement>(null);
  const imageUrls = useRef<Set<string>>(new Set());
  const history = useRef<string[]>([]);

  function visibleGarment(record: StoredGarment): Garment {
    const imageUrl = URL.createObjectURL(record.photo);
    imageUrls.current.add(imageUrl);
    const { photo: _photo, ...metadata } = record;
    return { ...metadata, imageUrl };
  }

  useEffect(() => {
    const formatted = new Intl.DateTimeFormat("es-CO", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
    setDateLabel(formatted.charAt(0).toUpperCase() + formatted.slice(1));
    getWardrobe()
      .then(({ garments, outfits }) => { setItems(garments.map(visibleGarment)); setFavorites(outfits); })
      .catch((err) => setError(err instanceof Error ? err.message : "No se pudo cargar tu armario."))
      .finally(() => setLoading(false));
    void requestPersistentStorage();
    return () => { for (const url of imageUrls.current) URL.revokeObjectURL(url); imageUrls.current.clear(); };
  }, []);

  useEffect(() => {
    if (!file) { setPreview(""); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if (!addOpen && !deleteItem) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") { setAddOpen(false); setDeleteItem(null); } };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [addOpen, deleteItem]);

  const displayItems = useMemo(() => items.filter((item) =>
    (filter === "all" || item.category === filter) &&
    (item.name.toLowerCase().includes(search.toLowerCase()) || catName(item.category).toLowerCase().includes(search.toLowerCase()))
  ), [items, filter, search]);
  const enough = items.some((g) => g.category === "top") && items.some((g) => ["pants", "shorts"].includes(g.category)) && items.some((g) => g.category === "shoes");
  const currentKey = current ? [current.top?.id, current.bottom?.id, current.shoes?.id, current.cap?.id || ""].join("|") : "";
  const isSaved = current ? favorites.some((f) => f.garmentIds.join("|") === [current.top?.id, current.bottom?.id, current.shoes?.id, ...(current.cap ? [current.cap.id] : [])].join("|")) : false;
  const fittingGarments: Selection = Object.fromEntries((Object.entries(fittingIds) as [Role, string][]).map(([role, id]) => [role, items.find((item) => item.id === id)])) as Selection;
  const fittingComplete = Boolean(fittingGarments.top && fittingGarments.bottom && fittingGarments.shoes);
  const fittingSaved = fittingComplete && favorites.some((f) => f.garmentIds.join("|") === [fittingGarments.top!.id, fittingGarments.bottom!.id, fittingGarments.shoes!.id, ...(fittingGarments.cap ? [fittingGarments.cap.id] : [])].join("|"));

  function navigate(dest: Section) { setSection(dest); setMobileMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function previewCurrentLook() {
    if (current) setFittingIds(Object.fromEntries((Object.entries(current) as [Role, Garment][]).filter(([, garment]) => garment).map(([role, garment]) => [role, garment.id])) as Partial<Record<Role, string>>);
    navigate("probador");
  }
  function openAdd(forCategory?: Category) { setCategory(forCategory || "top"); setName(""); setColor("negro"); setStyle("casual"); setFile(null); setEditorSource(null); setEditingExistingId(null); setAddOpen(true); }
  async function editSavedPhoto(item: Garment) {
    try {
      const saved = (await getWardrobe()).garments.find(g => g.id === item.id);
      if (!saved) throw new Error("No encontramos la fotografía original de esta prenda.");
      setEditingExistingId(item.id);
      setEditorSource(new File([saved.photo], "prenda-para-editar.png", { type: saved.photo.type }));
    } catch (e) { setToast(e instanceof Error ? e.message : "No pudimos editar la prenda."); }
  }
  async function acceptEditedPhoto(edited: File) {
    if (!editingExistingId) {
      setFile(edited);
      setEditorSource(null);
      setToast("Prenda recortada. Termina de completar sus datos y guárdala.");
      return;
    }
    setBusy(true);
    try {
      await updateGarmentPhoto(editingExistingId, edited);
      const updatedId = editingExistingId;
      setItems(old => old.map(item => {
        if (item.id !== updatedId) return item;
        URL.revokeObjectURL(item.imageUrl);
        imageUrls.current.delete(item.imageUrl);
        const newUrl = URL.createObjectURL(edited);
        imageUrls.current.add(newUrl);
        return { ...item, imageUrl: newUrl };
      }));
      setEditorSource(null); setEditingExistingId(null);
      setToast("Fotografía actualizada en tu armario y en tus outfits.");
    } catch (e) { setToast(e instanceof Error ? e.message : "No pudimos actualizar la foto."); }
    finally { setBusy(false); }
  }
  function generateLook() {
    const next = makeLook(items, occasion, locks, currentKey, history.current);
    if (!next) { setToast(enough ? "No hay más combinaciones con esas prendas bloqueadas." : "Añade una camisa, un pantalón o mocho y unos zapatos para comenzar."); return; }
    setCurrent(next.look);
    setFittingIds(Object.fromEntries((Object.entries(next.look) as [Role, Garment][]).filter(([, garment]) => garment).map(([role, garment]) => [role, garment.id])) as Partial<Record<Role, string>>);
    history.current = [...history.current, next.key].slice(-5);
  }
  function toggleLock(role: Role, item?: Garment) {
    if (!item) return;
    setLocks((old) => { const next = { ...old }; if (next[role] === item.id) delete next[role]; else next[role] = item.id; return next; });
  }
  async function addGarment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file) { setToast("Primero selecciona una foto de tu prenda."); return; }
    if (!file.type.startsWith("image/")) { setToast("Selecciona una fotografía válida."); return; }
    if (file.size > 15 * 1024 * 1024) { setToast("La foto no puede superar 15 MB."); return; }
    setBusy(true);
    try {
      const upload = await optimizePhoto(file);
      if (!["image/webp", "image/jpeg", "image/png"].includes(upload.type)) {
        throw new Error("Tu navegador no pudo convertir esta foto. Prueba con JPG, PNG o WebP.");
      }
      const record: StoredGarment = { id: crypto.randomUUID(), name: name.trim(), category, color, style, photo: upload, createdAt: Date.now() };
      await storeGarment(record);
      setItems((old) => [visibleGarment(record), ...old]); setAddOpen(false); setToast("Prenda guardada en este dispositivo.");
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo guardar."); }
    finally { setBusy(false); }
  }
  async function confirmDelete() {
    if (!deleteItem) return;
    setBusy(true);
    try {
      await deleteStoredGarment(deleteItem.id);
      setItems((old) => old.filter((g) => g.id !== deleteItem.id));
      setFavorites((old) => old.filter((f) => !f.garmentIds.includes(deleteItem.id)));
      URL.revokeObjectURL(deleteItem.imageUrl);
      imageUrls.current.delete(deleteItem.imageUrl);
      setLocks((old) => Object.fromEntries(Object.entries(old).filter(([, id]) => id !== deleteItem.id)) as Partial<Record<Role, string>>);
      if (Object.values(current || {}).some((g) => g?.id === deleteItem.id)) setCurrent(null);
      setDeleteItem(null); setToast("Prenda eliminada.");
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo eliminar."); }
    finally { setBusy(false); }
  }
  async function persistOutfit(selection: Selection) {
    if (!selection.top || !selection.bottom || !selection.shoes) return;
    setBusy(true);
    try {
      const garmentIds = [selection.top.id, selection.bottom.id, selection.shoes.id, ...(selection.cap ? [selection.cap.id] : [])];
      if (favorites.some((f) => f.garmentIds.join("|") === garmentIds.join("|"))) return;
      const outfit: Outfit = { id: crypto.randomUUID(), occasion, garmentIds, createdAt: Date.now() };
      await storeOutfit(outfit);
      setFavorites((old) => [outfit, ...old]);
      setToast("Look guardado en tus favoritos.");
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo guardar el look."); }
    finally { setBusy(false); }
  }
  async function saveOutfit() { if (current) await persistOutfit(current); }
  async function removeFavorite(id: string) {
    try {
      await deleteStoredOutfit(id);
      setFavorites((old) => old.filter((f) => f.id !== id)); setToast("Look eliminado de favoritos.");
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo eliminar."); }
  }

  async function downloadBackup() {
    setBusy(true);
    try {
      const fileName = await exportBackup(displayName);
      const now = new Date().toISOString();
      setLastBackup(now);
      try { localStorage.setItem("atelier-last-backup", now); } catch { /* private mode */ }
      setToast(`Descarga iniciada: ${fileName}. Guarda el ZIP en un lugar seguro.`);
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo crear la copia."); }
    finally { setBusy(false); }
  }

  async function restoreBackup(fileToImport: File) {
    if (!window.confirm("¿Restaurar esta copia? El armario y los looks actuales se reemplazarán. Descarga primero una copia si deseas conservarlos.")) return;
    setBusy(true);
    try {
      const result = await importBackup(fileToImport);
      const loaded = await getWardrobe();
      for (const url of imageUrls.current) URL.revokeObjectURL(url);
      imageUrls.current.clear();
      setItems(loaded.garments.map(visibleGarment));
      setFittingIds({});
      setFavorites(loaded.outfits);
      setCurrent(null);
      setLocks({});
      history.current = [];
      if (result.displayName) {
        setDisplayName(result.displayName);
        try { localStorage.setItem("atelier-display-name", result.displayName); } catch { /* private mode */ }
      }
      setToast(`Copia restaurada: ${result.count} prendas disponibles.`);
      navigate("armario");
    } catch (err) { setToast(err instanceof Error ? err.message : "No se pudo restaurar la copia."); }
    finally { if (backupInputRef.current) backupInputRef.current.value = ""; setBusy(false); }
  }

  function updateDisplayName(next: string) {
    setDisplayName(next);
    try { localStorage.setItem("atelier-display-name", next); } catch { /* private mode */ }
  }

  return (
    <div className="atelier-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand" onClick={() => navigate("inicio")} role="button" tabIndex={0} onKeyDown={(e) => e.key === "Enter" && navigate("inicio")}>
          <span className="brand-mark">A<span className="brand-mark-dot">.</span></span>
          <span className="brand-text"><strong>ATELIER</strong><small>THE WARDROBE EDIT</small></span>
        </div>
        <div className="sidebar-divider" />
        <p className="nav-title">TU ESPACIO</p>
        <nav className="nav-list" aria-label="Navegación principal">
          {nav.map(({ id, label, icon: Icon }) =>
            <button key={id} className={`nav-link ${section === id ? "active" : ""}`} onClick={() => navigate(id)}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{section === id && <span className="nav-active-dot" />}
            </button>
          )}
        </nav>
        <div className="sidebar-bottom">
          <div className="little-guide">
            <span className="little-guide-icon"><Sparkles size={19} /></span>
            <span className="eyebrow">YOUR STYLE, REIMAGINED</span>
            <strong>Menos dudas.<br />Más estilo.</strong>
            <p>Todo lo que necesitas ya está en tu armario.</p>
            <button onClick={() => navigate("estudio")}>Crear un look <ArrowUpRight size={15} /></button>
          </div>
          <div className="mini-profile"><span className="avatar">{(displayName || "A").slice(0, 1).toUpperCase()}</span><span><strong>{displayName || "Mi espacio"}</strong><small>Armario personal · Local</small></span><span className="profile-status" /></div>
        </div>
      </aside>
      {mobileMenu && <button className="mobile-screen" aria-label="Cerrar menú" onClick={() => setMobileMenu(false)} />}

      <div className="main-area">
        <header className="topbar">
          <button className="mobile-menu-btn" onClick={() => setMobileMenu(true)} aria-label="Abrir menú"><Menu size={22} /></button>
          <div className="mobile-brand">ATELIER<span>.</span></div>
          <div className="topbar-breadcrumb">TU ARMARIO <ChevronRight size={13} /> <strong>{nav.find((n) => n.id === section)?.label}</strong></div>
          <div className="topbar-actions"><span className="date-text">{dateLabel}</span><span className="topbar-line" /><button className="topbar-add" onClick={() => openAdd()}><Plus size={17} /><span>Añadir prenda</span></button><span className="avatar avatar-top">{(displayName || "A").slice(0, 1).toUpperCase()}</span></div>
        </header>

        <main className="page-content">
          {error && <div className="notice"><span>{error}</span><button onClick={() => window.location.reload()}>Reintentar <RefreshCw size={14} /></button></div>}
          {section === "inicio" && <>
            <div className="page-kicker"><span className="kicker-line" /> BIENVENIDO A TU ESTILO</div>
            <div className="welcome-row"><div><h1>Hola, {displayName || "amigo"}<span className="serif-dot">.</span></h1><p>Un buen look empieza con lo que ya tienes.</p></div><span className="edition-pill"><span /> TU EDICIÓN PERSONAL</span></div>
            <div className="hero">
              <div className="hero-copy"><p className="hero-kicker"><Sparkles size={14} /> THE DAILY EDIT / 001</p><h2>Vestir bien<br /><em>es cuestión</em><br />de combinar.</h2><p>Descubre nuevas formas de llevar tus prendas. Tu armario, reinterpretado cada día.</p><button className="btn btn-cream" onClick={() => navigate("estudio")}>Crear mi outfit <ArrowUpRight size={18} /></button></div>
              <div className="hero-art" aria-hidden="true">
                <div className="hero-art-ring ring-one" /><div className="hero-art-ring ring-two" />
                <div className="editorial-label">01 — YOUR EDIT</div>
                <div className="hero-tile tile-back"><GarmentImage item={items[1]} category="pants" /></div>
                <div className="hero-tile tile-front"><GarmentImage item={items[0]} category="top" /></div>
                <div className="hero-art-caption">PERSONAL STYLE<br />COLLECTION</div>
              </div>
            </div>
            <div className="stats-grid">
              <div className="stat-card"><div className="stat-icon"><Shirt size={20} /></div><span>TOTAL DE PRENDAS</span><strong>{loading ? "—" : String(items.length).padStart(2, "0")}</strong><small>En tu colección</small></div>
              <div className="stat-card"><div className="stat-icon"><Layers3 size={20} /></div><span>CATEGORÍAS</span><strong>{loading ? "—" : String(new Set(items.map((g) => g.category)).size).padStart(2, "0")}<i>/05</i></strong><small>Organizadas por tipo</small></div>
              <div className="stat-card"><div className="stat-icon"><Heart size={20} /></div><span>LOOKS GUARDADOS</span><strong>{loading ? "—" : String(favorites.length).padStart(2, "0")}</strong><small>Tus combinaciones favoritas</small></div>
            </div>
            {items.length > 0 && !lastBackup && <div className="backup-reminder"><ShieldCheck size={20} /><div><strong>Tus prendas están guardadas aquí.</strong><span>Para protegerlas al cambiar de celular, descarga una copia de tu armario.</span></div><button onClick={() => navigate("respaldo")}>Crear copia <ArrowRight size={15} /></button></div>}
            <div className="section-head"><div><p className="page-kicker">TU COLECCIÓN</p><h2>Tu armario, de cerca</h2></div><button className="text-action" onClick={() => navigate("armario")}>Ver mi armario <ArrowRight size={16} /></button></div>
            {items.length ? <div className="recent-grid">{items.slice(0, 4).map((item) => <button className="recent-item" key={item.id} onClick={() => { setFilter(item.category); navigate("armario"); }}><GarmentImage item={item} /><span>{item.name}</span><small>{catName(item.category)}</small></button>)}</div> :
              <div className="start-collection"><div className="start-icon"><CloudUpload size={27} strokeWidth={1.4} /></div><div><strong>Tu colección comienza aquí.</strong><p>Sube la primera foto de tu ropa y construye tu armario digital.</p></div><button className="btn btn-dark" onClick={() => openAdd()}>Añadir primera prenda <Plus size={17} /></button></div>}
            <div className="bottom-note"><span>ATELIER JOURNAL</span><p>“El estilo no depende de tener más ropa, sino de descubrir más posibilidades.”</p><span>EST. 2026</span></div>
          </>}

          {section === "armario" && <>
            <div className="page-kicker"><span className="kicker-line" /> LA COLECCIÓN</div>
            <div className="section-intro"><div><h1>Mi armario<span className="serif-dot">.</span></h1><p>Cada prenda, en su lugar. Cada combinación, por descubrir.</p></div><button className="btn btn-dark intro-button" onClick={() => openAdd()}><Plus size={18} /> Añadir prenda</button></div>
            <div className="collection-toolbar"><div className="filter-pills"><button className={filter === "all" ? "selected" : ""} onClick={() => setFilter("all")}>Todas <span>{items.length}</span></button>{categories.map((cat) => <button key={cat.id} className={filter === cat.id ? "selected" : ""} onClick={() => setFilter(cat.id)}>{cat.plural} <span>{items.filter((i) => i.category === cat.id).length}</span></button>)}</div><label className="search-box"><Search size={17} /><input placeholder="Buscar prenda..." value={search} onChange={(e) => setSearch(e.target.value)} /></label></div>
            <div className="collection-count"><span>{displayItems.length} {displayItems.length === 1 ? "PRENDA" : "PRENDAS"}</span><span><SlidersHorizontal size={14} /> COLECCIÓN PERSONAL</span></div>
            {displayItems.length ? <div className="wardrobe-grid">{displayItems.map((item, index) =>
              <div className="garment-card" key={item.id}><div className="garment-card-image"><GarmentImage item={item} /><span className="garment-index">{String(index + 1).padStart(2, "0")}</span><button className="delete-overlay" aria-label={`Eliminar ${item.name}`} onClick={() => setDeleteItem(item)}><Trash2 size={17} /></button><button className="edit-photo-button" aria-label={`Quitar fondo de ${item.name}`} onClick={() => void editSavedPhoto(item)}><Crop size={14}/> Quitar fondo</button></div><div className="garment-card-info"><strong>{item.name}</strong><span>{catName(item.category)}</span><div className="garment-card-bottom"><span className="color-dot" style={{ background: colors.find((c) => c.id === item.color)?.hex }} /> {colorName(item.color)}<span className="style-tag">{item.style}</span></div></div></div>
            )}<button className="add-card" onClick={() => openAdd()}><span><Plus size={25} /></span><strong>Añadir otra prenda</strong><small>Haz crecer tu colección</small></button></div> :
              <div className="empty-panel"><div className="empty-icon"><Shirt size={32} strokeWidth={1.2} /></div><h3>{items.length ? "No encontramos prendas" : "Tu armario está esperando"}</h3><p>{items.length ? "Prueba con otra categoría o búsqueda." : "Fotografía tus camisas, pantalones, mochos, zapatos y gorras para comenzar."}</p><button className="btn btn-dark" onClick={() => items.length ? (setFilter("all"), setSearch("")) : openAdd()}>{items.length ? "Ver todas las prendas" : "Añadir mi primera prenda"} <ArrowRight size={17} /></button></div>}
          </>}

          {section === "estudio" && <>
            <div className="page-kicker"><span className="kicker-line" /> OUTFIT STUDIO</div>
            <div className="section-intro"><div><h1>El look del día<span className="serif-dot">.</span></h1><p>Combinaciones pensadas para ti, con tu propia ropa.</p></div><span className="edition-pill"><span /> TU ESTILISTA PERSONAL</span></div>
            <div className="studio-layout"><div className="studio-main">
              <div className="style-selector"><div className="section-head compact"><div><p className="page-kicker">PASO 01</p><h2>¿Qué estilo buscas?</h2></div></div><div className="occasion-grid">{occasions.map((o) => <button key={o.id} className={`occasion-card ${occasion === o.id ? "chosen" : ""}`} onClick={() => { setOccasion(o.id); setCurrent(null); history.current = []; }}><span className="occasion-check">{occasion === o.id && <Check size={13} />}</span><strong>{o.label}</strong><small>{o.subtitle}</small></button>)}</div></div>
              <div className="look-heading"><div><p className="page-kicker">PASO 02</p><h2>Tu combinación <em>ideal</em></h2></div>{current && <span className="generated-tag"><CheckCheck size={14} /> LOOK GENERADO</span>}</div>
              {enough ? <>
                <div className="studio-combined-look">
                  <div className="studio-combined-stage"><span className="outfit-stage-eyebrow">ATELIER / TU LOOK COMPLETO</span><OutfitCollage pieces={current || {}} /><span className="outfit-stage-footer">SIN PERSONAJE · TUS PRENDAS UNIDAS</span></div>
                  <div className="studio-combined-details"><p className="page-kicker">EL LOOK, PRENDA POR PRENDA</p><h3>Todo <em>en armonía.</em></h3><p>La camiseta, el pantalón y los zapatos aparecen juntos, como si estuvieran sobre un cuerpo invisible.</p><div className="outfit-piece-list">{roles.map((role) => { const item = current?.[role.id]; const isLocked = Boolean(item && locks[role.id] === item.id); return <div className="outfit-piece-row" key={role.id}><span className="outfit-piece-num">{role.number}</span><div><small>{role.label}</small><strong>{item?.name || (role.id === "cap" ? "Sin gorra" : "Por descubrir")}</strong></div>{item && <button className={isLocked ? "locked" : ""} aria-label={isLocked ? `Desbloquear ${item.name}` : `Mantener ${item.name}`} title={isLocked ? "Desbloquear prenda" : "Mantener al generar otro"} onClick={() => toggleLock(role.id, item)}>{isLocked ? <LockKeyhole size={18} /> : <UnlockKeyhole size={18} />}</button>}</div>; })}</div></div>
                </div>
                <div className="studio-actions"><button className="btn btn-dark generate-button" onClick={generateLook}><RefreshCw size={18} /> {current ? "Crear otro conjunto" : "Crear conjunto del día"}</button><button className={`btn btn-outline save-button ${isSaved ? "saved" : ""}`} disabled={!current || isSaved || busy} onClick={saveOutfit}><Heart size={17} fill={isSaved ? "currentColor" : "none"} /> {isSaved ? "Guardado" : "Guardar look"}</button>{current && <button className="btn btn-outline save-button" onClick={previewCurrentLook}><Layers3 size={17} /> Abrir probador</button>}</div>
                {current && <p className="studio-tip"><LockKeyhole size={15} /> ¿Te gusta una prenda? Toca el candado para mantenerla al generar otro look.</p>}
              </> :
                <div className="empty-studio"><div className="empty-icon"><WandSparkles size={29} /></div><h3>Primero, armemos tu colección.</h3><p>Para crear un outfit necesitas al menos una camisa, un pantalón o mocho y unos zapatos.</p><div className="requirements"><span className={items.some((g) => g.category === "top") ? "done" : ""}>{items.some((g) => g.category === "top") ? "✓" : "+"} Camisa</span><span className={items.some((g) => ["pants", "shorts"].includes(g.category)) ? "done" : ""}>{items.some((g) => ["pants", "shorts"].includes(g.category)) ? "✓" : "+"} Pantalón o mocho</span><span className={items.some((g) => g.category === "shoes") ? "done" : ""}>{items.some((g) => g.category === "shoes") ? "✓" : "+"} Zapatos</span></div><button className="btn btn-dark" onClick={() => navigate("armario")}>Ir a mi armario <ArrowRight size={16} /></button></div>}
            </div><aside className="studio-aside"><div className="stylist-card"><div className="stylist-icon"><Sparkles size={21} /></div><span className="eyebrow">UNA NOTA DE ESTILO</span><h3>La magia está<br /><em>en combinar.</em></h3><p>Elegimos conjuntos usando los colores de tus prendas y el estilo que seleccionas. Cada nueva propuesta es diferente.</p><div className="stylist-divider" /><span className="stylist-foot">TU ARMARIO / TUS REGLAS <ArrowUpRight size={15} /></span></div><div className="mini-closet"><div><strong>{items.length} prendas disponibles</strong><span>Tu colección actual</span></div><button onClick={() => navigate("armario")}><ArrowUpRight size={19} /></button></div></aside></div>
          </>}

          {section === "probador" && <>
            <div className="page-kicker"><span className="kicker-line" /> PROBADOR PERSONAL</div>
            <div className="section-intro"><div><h1>Tu conjunto <em className="avatar-title-accent">unido.</em></h1><p>Camisa, pantalón y zapatos sin espacios: un look completo sobre un cuerpo invisible.</p></div><span className="edition-pill"><span /> TUS FOTOS · TU ESTILO</span></div>
            <div className="fitting-layout">
              <div className="fitting-stage"><div className="fitting-stage-header"><span>ATELIER / FITTING ROOM</span><span>VISTA DEL LOOK</span></div><OutfitCollage pieces={fittingGarments} adjustments={fittingAdjustments}/><div className="fitting-stage-bottom">UNA SOLA COMBINACIÓN · SIN AVATAR</div></div>
              <div className="fitting-panel"><span className="page-kicker">01 / ELIGE TUS PRENDAS</span><h2>Combínalo.</h2><p>Selecciona las prendas de tu armario. La vista se actualiza al instante, uniendo camiseta, pantalón y zapatos sin tarjetas separadas.</p>
                <div className="avatar-pickers">{roles.map((role) => { const choices = items.filter((item) => role.id === "bottom" ? item.category === "pants" || item.category === "shorts" : item.category === role.id); const selected = fittingGarments[role.id]; return <label className="avatar-picker" key={role.id}><span>{role.label.toUpperCase()}</span><select value={fittingIds[role.id] || ""} onChange={(event) => setFittingIds((old) => ({ ...old, [role.id]: event.target.value || undefined }))}><option value="">{role.id === "cap" ? "Sin gorra" : "Elegir prenda"}</option>{choices.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>{selected && <div className="avatar-selected"><img src={selected.imageUrl} alt={selected.name} /><span>{selected.name} · {colorName(selected.color)}</span></div>}</label>; })}</div>
                <div className="fitting-fine-tune"><div className="fitting-tune-heading"><span className="page-kicker">02 / AJUSTA TU LOOK</span><button onClick={() => setFittingAdjustments({})}><RefreshCw size={13}/> Restablecer</button></div><p>Acerca las prendas, muévelas y ajusta el tamaño hasta que se vean como un solo conjunto.</p>{roles.filter(r => fittingGarments[r.id]).map(role => { const adjust = fittingAdjustments[role.id] || { scale: 1, x: 0, y: 0 }; const update = (field: "scale" | "x" | "y", value: number) => setFittingAdjustments(old => ({ ...old, [role.id]: { ...adjust, [field]: value } })); return <div className="fitting-tune-row" key={role.id}><strong>{role.label}</strong><label>Tamaño <input type="range" min="0.6" max="1.6" step="0.05" value={adjust.scale} onChange={e => update("scale", Number(e.target.value))}/></label><label>Altura <input type="range" min="-40" max="40" value={adjust.y} onChange={e => update("y", Number(e.target.value))}/></label><label>Centro <input type="range" min="-40" max="40" value={adjust.x} onChange={e => update("x", Number(e.target.value))}/></label></div>; })}</div>
                <button className="btn btn-dark fitting-generate" disabled={!enough} onClick={generateLook}><RefreshCw size={17} /> Crear otro conjunto</button>
                <button className={`btn btn-outline fitting-save ${fittingSaved ? "saved" : ""}`} disabled={!fittingComplete || fittingSaved || busy} onClick={() => { void persistOutfit(fittingGarments); }}><Heart size={17} fill={fittingSaved ? "currentColor" : "none"} /> {fittingSaved ? "Guardado en favoritos" : "Guardar esta combinación"}</button>
                <button className="fitting-manage" onClick={() => navigate("armario")}>Administrar mis prendas <ArrowRight size={15}/></button>
              </div>
            </div>
            <div className="avatar-disclaimer"><ShieldCheck size={19}/><p><strong>Tu probador es privado y gratuito.</strong> Al subir una nueva prenda puedes recortar capturas de tiendas y eliminar el fondo con IA local. Las prendas antiguas también se pueden corregir desde «Mi armario» → «Quitar fondo». Las imágenes con modelos o fondos complejos pueden necesitar ajustes manuales.</p></div>
          </>}

          {section === "favoritos" && <>
            <div className="page-kicker"><span className="kicker-line" /> LOOKBOOK PERSONAL</div>
            <div className="section-intro"><div><h1>Mis favoritos<span className="serif-dot">.</span></h1><p>Todos esos looks que merecen una segunda oportunidad.</p></div><button className="btn btn-dark intro-button" onClick={() => navigate("estudio")}>Crear nuevo look <ArrowUpRight size={16} /></button></div>
            <div className="collection-count"><span>{favorites.length} LOOKS GUARDADOS</span><span>YOUR PERSONAL LOOKBOOK</span></div>
            {favorites.length ? <div className="favorite-grid">{favorites.map((fav, index) => { const owned = fav.garmentIds.map((id) => items.find((g) => g.id === id)).filter(Boolean) as Garment[]; const top = owned.find((g) => g.category === "top"); const bottom = owned.find((g) => ["pants", "shorts"].includes(g.category)); const shoes = owned.find((g) => g.category === "shoes"); const cap = owned.find((g) => g.category === "cap"); return <div className="favorite-card" key={fav.id}><div className="favorite-top"><span>LOOK {String(index + 1).padStart(2, "0")}</span><button aria-label="Eliminar favorito" title="Eliminar favorito" onClick={() => removeFavorite(fav.id)}><Trash2 size={16} /></button></div><div className="favorite-composition"><OutfitCollage pieces={{ top, bottom, shoes, cap }} compact /></div><div className="favorite-footer"><div><strong>{occasionName(fav.occasion)}</strong><small>{new Intl.DateTimeFormat("es-CO", { day: "numeric", month: "short" }).format(fav.createdAt)}</small></div><button className="circle-arrow" onClick={() => { if (!top || !bottom || !shoes) { setToast("Este look tiene prendas eliminadas."); return; } setCurrent({ top, bottom, shoes, cap }); setFittingIds({ top: top.id, bottom: bottom.id, shoes: shoes.id, cap: cap?.id }); setOccasion(fav.occasion); setLocks({}); navigate("estudio"); }} aria-label="Ver look"><ArrowUpRight size={18} /></button></div></div>; })}</div> :
              <div className="empty-panel"><div className="empty-icon"><Heart size={30} strokeWidth={1.3} /></div><h3>Tu lookbook está en blanco</h3><p>Cuando encuentres una combinación que te encante, guárdala aquí para volver a usarla.</p><button className="btn btn-dark" onClick={() => navigate("estudio")}>Descubrir combinaciones <ArrowRight size={17} /></button></div>}
          </>}

          {section === "respaldo" && <>
            <div className="page-kicker"><span className="kicker-line" /> TU INFORMACIÓN, EN TUS MANOS</div>
            <div className="section-intro"><div><h1>Mis copias<span className="serif-dot">.</span></h1><p>Tu armario es tuyo. Protégelo y llévalo contigo cuando cambies de teléfono.</p></div><span className="edition-pill"><span /> 100% EN TU DISPOSITIVO</span></div>
            <div className="backup-banner"><div className="backup-banner-icon"><ShieldCheck size={26} /></div><div><span>PRIVACIDAD POR DISEÑO</span><h2>Tu ropa no se sube a ninguna nube.</h2><p>Las fotografías, prendas y conjuntos viven en este navegador. No necesitas tarjeta, cuentas, servidores ni conexión para organizar tu estilo.</p></div></div>
            <div className="backup-grid">
              <div className="backup-card"><span className="backup-card-step">01 / PROTEGER</span><div className="backup-icon"><Download size={26} /></div><h3>Guardar mi armario</h3><p>Descarga un ZIP con las fotos de tus prendas y todos tus conjuntos favoritos. Guárdalo en un lugar seguro.</p><div className="backup-card-meta"><strong>{items.length} prendas</strong><span>·</span><strong>{favorites.length} favoritos</strong></div><button className="btn btn-dark" disabled={busy || loading} onClick={downloadBackup}><Download size={17} /> {busy ? "Preparando archivo..." : "Descargar copia ZIP"}</button></div>
              <div className="backup-card"><span className="backup-card-step">02 / RECUPERAR</span><div className="backup-icon"><Upload size={26} /></div><h3>Restaurar mi armario</h3><p>¿Cambiaste de celular? Abre ATELIER en el nuevo dispositivo y selecciona el ZIP que guardaste para recuperar tu colección.</p><div className="backup-card-warning">Importante: restaurar reemplaza las prendas y favoritos que ya tengas en este dispositivo.</div><input ref={backupInputRef} type="file" accept=".zip,application/zip" className="backup-file-input" onChange={(e) => { const f = e.target.files?.[0]; if (f) void restoreBackup(f); }} /><button className="btn btn-outline" disabled={busy} onClick={() => backupInputRef.current?.click()}><ArchiveRestore size={17} /> {busy ? "Procesando..." : "Elegir una copia ZIP"}</button></div>
            </div>
            <div className="backup-details"><div><span className="page-kicker">TUS PREFERENCIAS</span><h3>Nombre de tu espacio</h3><p>Así te saludará ATELIER cada vez que lo abras.</p></div><label className="backup-name"><span>¿CÓMO TE LLAMAS?</span><input value={displayName} maxLength={40} placeholder="Tu nombre" onChange={(e) => updateDisplayName(e.target.value)} /></label></div>
            <div className="backup-footnote"><ShieldCheck size={19} /><div><strong>Un consejo importante:</strong> {lastBackup ? `Iniciaste una descarga de respaldo el ${new Intl.DateTimeFormat("es-CO", { day: "numeric", month: "long", year: "numeric" }).format(new Date(lastBackup))}. ` : "Aún no has iniciado una descarga de respaldo. "}Si borras los datos del navegador, desinstalas el navegador o cambias de teléfono, podrías perder estas fotos. Conserva el ZIP en un lugar seguro y haz una copia cada vez que añadas varias prendas.</div></div>
          </>}
        </main>
        <footer className="main-footer"><span>ATELIER © 2026</span><span>CURATED FOR YOUR EVERYDAY</span></footer>
      </div>

      <nav className="mobile-bottom-nav" aria-label="Navegación rápida">{nav.map(({ id, icon: Icon }) => <button key={id} className={section === id ? "active" : ""} onClick={() => navigate(id)}><Icon size={21} strokeWidth={1.7} /><span>{id === "estudio" ? "Outfits" : id === "probador" ? "Probador" : id === "armario" ? "Armario" : id === "favoritos" ? "Favoritos" : id === "respaldo" ? "Copias" : "Inicio"}</span></button>)}</nav>

      {addOpen && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && !busy && setAddOpen(false)}><div className="upload-modal" role="dialog" aria-modal="true" aria-labelledby="upload-title"><div className="modal-heading"><div><span className="page-kicker">NUEVA ADICIÓN</span><h2 id="upload-title">Añadir prenda<span className="serif-dot">.</span></h2></div><button aria-label="Cerrar" onClick={() => !busy && setAddOpen(false)}><X size={22} /></button></div><form onSubmit={addGarment}><label className="upload-drop"><input type="file" accept="image/jpeg,image/png,image/webp,image/heic,image/heif" onChange={(e) => { const selected = e.target.files?.[0] || null; if (selected) { setFile(null); setEditingExistingId(null); setEditorSource(selected); } e.target.value = ""; }} />{preview ? <><img src={preview} alt="Vista previa de la prenda" /><span className="change-photo">Cambiar fotografía <RefreshCw size={13} /></span></> : <><span className="upload-icon"><CloudUpload size={29} strokeWidth={1.4} /></span><strong>Foto o captura de tienda</strong><small>Toca para subir desde la cámara o galería</small><span className="upload-help">ATELIER Studio te ayudará a recortar y quitar el fondo · Máx. 15 MB</span></>}</label><div className="form-grid"><label className="form-field full"><span>NOMBRE DE LA PRENDA</span><input required maxLength={70} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Camiseta negra oversize" /></label><label className="form-field"><span>CATEGORÍA</span><select value={category} onChange={(e) => setCategory(e.target.value as Category)}>{categories.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select></label><label className="form-field"><span>ESTILO</span><select value={style} onChange={(e) => setStyle(e.target.value as Style)}>{occasions.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select></label><label className="form-field full"><span>COLOR PRINCIPAL</span><div className="color-picker">{colors.map((c) => <button key={c.id} type="button" className={color === c.id ? "selected" : ""} aria-label={c.label} title={c.label} onClick={() => setColor(c.id)}><span style={{ background: c.hex }} />{color === c.id && <Check size={12} />}</button>)}</div><small className="selected-color">Seleccionado: {colorName(color)}</small></label></div>{file && <button type="button" className="editor-again" onClick={() => setEditorSource(file)}><Crop size={15}/> Volver a editar esta imagen</button>}<button className="btn btn-dark save-garment" type="submit" disabled={busy || !file || !name.trim()}>{busy ? <RefreshCw className="spin" size={18} /> : <Plus size={18} />}{busy ? "Guardando tu prenda..." : "Guardar en mi armario"}</button></form></div></div>}
      {editorSource && <GarmentEditor key={`${editingExistingId || "new"}-${editorSource.name}-${editorSource.size}`} source={editorSource} onCancel={() => { setEditorSource(null); setEditingExistingId(null); }} onDone={(photo) => void acceptEditedPhoto(photo)}/>}
      {deleteItem && <div className="modal-backdrop"><div className="confirm-modal" role="alertdialog" aria-modal="true"><div className="confirm-icon"><Trash2 size={23} /></div><h2>¿Eliminar esta prenda?</h2><p>Se borrarán <strong>{deleteItem.name}</strong> y su fotografía de tu armario. Esta acción no se puede deshacer.</p><div><button className="btn btn-outline" disabled={busy} onClick={() => setDeleteItem(null)}>Cancelar</button><button className="btn btn-danger" disabled={busy} onClick={confirmDelete}>{busy ? "Eliminando..." : "Sí, eliminar"}</button></div></div></div>}
      {toast && <div className="toast" role="status"><span className="toast-circle"><Sparkles size={15} /></span>{toast}<button onClick={() => setToast("")} aria-label="Cerrar aviso"><X size={14} /></button></div>}
    </div>
  );
}
