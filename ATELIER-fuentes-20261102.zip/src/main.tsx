import { createRoot } from "react-dom/client";
import WardrobeApp from "./wardrobe-app";
import "./globals.css";

createRoot(document.getElementById("root")!).render(
  <WardrobeApp firstName="Stiven" />,
);
